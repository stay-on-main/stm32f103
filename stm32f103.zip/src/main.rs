#![no_main]
#![no_std]

mod startup;
pub mod pherepherial;

use pherepherial::gpiob;
use pherepherial::rcc;
use pherepherial::usart1;

fn usart_init() {
    let mut rcc = rcc::apb2enr::read();
    rcc.usart1en_set(1);
    rcc::apb2enr::write(&rcc);

    
}

#[no_mangle]
pub fn main() {
    let mut rcc = rcc::apb2enr::read();
    rcc.iopben_set(1);
    rcc::apb2enr::write(&rcc);

    let mut crh = gpiob::crh::read();
    crh.mode12_set(1); // output 50 MHz
    crh.cnf12_set(0); // general purpose push-pull
    gpiob::crh::write(&crh);

    let mut odr = gpiob::odr::read();
    odr.odr12_set(0);
    gpiob::odr::write(&odr);

    loop {
        /*
        let mut bsrr = pherepherial::gpiob::bsrr::read();
        //bsrr.bs4_set(1);
        //pherepherial::gpiob::bsrr::write(&bsrr);

        //bsrr.bs4_set(0);
        bsrr.br4_set(1);
        pherepherial::gpiob::bsrr::write(&bsrr);
        */
    }
}